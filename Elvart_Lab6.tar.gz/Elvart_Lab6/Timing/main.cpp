


#include <iostream>
#include "Test.h"

int main(int argc, char** argv)
{
  Test tester;
  tester.runTestSuite();
  //std::cout<<"Hello world!\n";
}
