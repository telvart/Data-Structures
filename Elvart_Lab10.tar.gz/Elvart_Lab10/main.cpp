
#include <iostream>
#include "MSTSolver.h"

int main(int argc, char** argv)
{
 MSTSolver m = MSTSolver("data.txt");
 m.run();

}
