
#ifndef TEST_H
#define TEST_H

#include "MSTSolver.h"
#include "Timer.h"

class Test{

public:
  void run();


};


#endif
