
#include <iostream>
#include "MSTSolver.h"
#include "Test.h"

int main(int argc, char** argv)
{
Test test;
test.run();

}
