#include "SPSolver.h"

int main(int argc, char** argv)
{
  SPSolver solver = SPSolver();
  solver.run();
}
