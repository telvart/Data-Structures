#include "SHNode.h"

SHNode::SHNode(int val)
{
  m_val=val;
  m_left=nullptr;
  m_right=nullptr;
}
