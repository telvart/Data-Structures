#ifndef SHNODE_H
#define SHNODE_H

class SHNode
{
  public:

  SHNode(int val);
  int m_val;
  SHNode* m_left;
  SHNode* m_right;

};

#endif
