
#include "Test.h"
#include <iostream>

int main(int argc, char** argv)
{
  Test tester;
  tester.runTest();
}
